insert into dbo.Ta (aid, a2) values (1, 2), (2, 3), (3, 4), (4, 5), (5, 6)
insert into dbo.Tb (bid, b2) values (1, 4), (2, 8), (3, 12), (4, 16), (5, 20)
insert into dbo.Tc (cid, c2, aid, bid) values (1, 5, 1, 1), (2, 5, 4, 4), (3, 5, 2, 5), (4, 19, 4, 3), (5, 25, 5, 2)